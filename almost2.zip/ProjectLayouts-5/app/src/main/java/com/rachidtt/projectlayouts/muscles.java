package com.rachidtt.projectlayouts;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;



public class muscles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muscles);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/


    /*public void back_button(View view)
    {
        setContentView(R.layout.activity_back_work);
    }*/
        ImageButton advancetoback = (ImageButton) findViewById(R.id.BackButton);
        advancetoback.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, back_work.class);
                startActivity(intent);
            }

        });


        ImageButton advancetobiceps = (ImageButton) findViewById(R.id.BicepsButton);
        advancetobiceps.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, biceps_work.class);
                startActivity(intent);
            }

        });

        ImageButton advancetochest = (ImageButton) findViewById(R.id.ChestButton);
        advancetochest.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, chest_work.class);
                startActivity(intent);
            }

        });

        ImageButton advancetolegs = (ImageButton) findViewById(R.id.LegsButton);
        advancetolegs.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, legs_work.class);
                startActivity(intent);
            }

        });

        ImageButton advancetotriceps = (ImageButton) findViewById(R.id.TricepsButton);
        advancetotriceps.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, triceps_work.class);
                startActivity(intent);
            }

        });

        ImageButton advancetoshoulders = (ImageButton) findViewById(R.id.ShouldersButton);
        advancetoshoulders.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, shoulders_work.class);
                startActivity(intent);
            }

        });

        ImageButton advancetoabs = (ImageButton) findViewById(R.id.AbsButton);
        advancetoabs.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(muscles.this, abs_work.class);
                startActivity(intent);
            }

        });



    }

}


