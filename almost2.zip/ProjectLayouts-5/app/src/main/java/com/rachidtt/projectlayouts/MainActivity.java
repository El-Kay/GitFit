package com.rachidtt.projectlayouts;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    //boolean goal;
    //int age;
    //char sex;
    //int weight;
    //int height_feet;
    //int height_inch;
    Integer Weight;
    Integer Feet;
    Integer Inches;
    Integer Age;
    String Sex;


    //EditText Age_edit;



    SQLiteDatabase db;
    SQLiteDatabase db2;


    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Age_edit = (EditText)findViewById(R.id.agetext);

        db = openOrCreateDatabase("MyDatabase", MODE_PRIVATE, null);

        db.execSQL("Create table if not exists MyTable (Age int,  Weight int);");

        db2 = openOrCreateDatabase("MyDatabase", MODE_PRIVATE, null);

        db2.execSQL("Create table if not exists MyTable (Feet int,  Inches int);");





    }


    public native String stringFromJNI();




    public void start_button(View view)
    {
        setContentView(R.layout.information_screen);
    }



    public void bmi_button(View view)
    {
        Spinner GendSpinner=(Spinner) findViewById(R.id.sex_spinner);
        Spinner WeiSpinner=(Spinner) findViewById(R.id.weight_spinner);
        Spinner ftSpinner=(Spinner) findViewById(R.id.spinner_feet);
        Spinner inSpinner=(Spinner) findViewById(R.id.spinner_inches);
        EditText age_edit=(EditText) findViewById(R.id.age_edit_text); //new


        String temp_height_ft = ftSpinner.getSelectedItem().toString();
        String temp_height_in = inSpinner.getSelectedItem().toString();
        String temp_weight = WeiSpinner.getSelectedItem().toString();
        String temp_age= age_edit.getText().toString();  //new

        Integer Weight = Integer.parseInt(temp_weight);
        Integer Feet=Integer.parseInt(temp_height_ft);
        Integer Inches=Integer.parseInt(temp_height_in);
        Integer Age=Integer.parseInt(temp_age); //NEW
        String Sex = GendSpinner.getSelectedItem().toString();


        db.execSQL("Insert into MyTable values(" + Integer.toString(Age)+
                "," + Integer.toString(Weight) + ");");

        db2.execSQL("Insert into MyTable values(" + Integer.toString(Feet)+
                "," + Integer.toString(Inches) + ");");
        /*db.execSQL("Insert into MyTable values(" + Integer.toString(Age)+
                "," + Integer.toString(Weight)+" " + Integer.toString(Feet)+ " " + Integer.toString(Inches)  + ");");*/
        Double weightkg=Weight*0.453592;
        Double height=(Feet*0.3048)+(Inches*0.0254);
        Double bmi= weightkg/(height*height);

        Toast.makeText(this,"Your BMI is "+bmi,Toast.LENGTH_LONG).show();


        if(Age>13 && Age<100) {
            //setContentView(R.layout.activity_muscles);
        }
        else
        {
            Toast.makeText(this,"Age must be between 13 and 100",Toast.LENGTH_LONG).show();

        }

        Button advancetomuscles = (Button) findViewById(R.id.confirm_button);
        advancetomuscles.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {


                Intent intent = new Intent(MainActivity.this, muscles.class);
                startActivity(intent);
            }

        });

    }







}
